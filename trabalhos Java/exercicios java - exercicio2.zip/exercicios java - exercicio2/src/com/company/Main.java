package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("introduza um número o limite: ");

        int limite = scan.nextInt();

        int i,num,soma;

        for (num=1;num<limite;num++){
            soma = 0;
            for (i=1;i<num;i++) {
                if (num % i == 0)
                    soma += i;
            }
            if (soma == num)
                System.out.println("O número " + num + " é perfeito");
        }
    }
}
