package com.company;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        Random rand = new Random();
        ArrayList<Integer> valores = new ArrayList();

        for(int i=0;i<20;i++){
            valores.add(rand.nextInt(100));
            System.out.print(valores.get(i)+"  ");
        }
        System.out.println();
        System.out.println("Indique qual o índice do elemento a eliminar (1 a 20): ");
        int a = scan.nextInt();
        valores.remove(a-1);

        for(int j=0;j<valores.size();j++) {
            System.out.print(valores.get(j)+"  ");
        }
    }
}