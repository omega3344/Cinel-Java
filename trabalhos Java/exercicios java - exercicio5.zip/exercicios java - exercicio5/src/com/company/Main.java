package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        int num;
        int soma = 0;

        System.out.println("Introduza os valores a somar (0 para interromper):");

        do {
                num = scan.nextInt();
                soma+=num;
        } while (num!=0);

        System.out.println("A soma dos valores introduzidos é : "+soma);
    }
}

