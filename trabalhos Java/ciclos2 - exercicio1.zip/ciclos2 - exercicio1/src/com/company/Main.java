package com.company;

public class Main {

    public static void main(String[] args) {

        int contador = 0;

        for(int a=1;a<5;a++){
            for(int b=1;b<5;b++){
                for(int c=1;c<5;c++){
                    if((a!=b)&&(a!=c)&&(b!=c)){
                        System.out.println(""+a+b+c);
                        contador++;
                    }
                }
            }
        }
        System.out.println("O total de números de três digitos é "+contador);
    }
}
