package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("introduza um número o limite: ");
        int limite = scan.nextInt();

        int rand;
        int soma = 0;
        int contador = 0;

        while (soma<limite) {
            rand = 1 + (int) (Math.random() * 10);
            System.out.println(rand);
            soma += rand;
            contador++;
            }
        System.out.println("O número de valores gerados foi "+contador+" e a soma total é :"+soma);
    }
}
