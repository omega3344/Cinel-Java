package com.company;

import java.util.Random;

public class Main {

    public static void main(String[] args) {

        Random rand = new Random();

        int[] valores = new int[20];
        int max = Integer.MIN_VALUE;
        int min = Integer.MAX_VALUE;

        for(int i=0;i<20;i++){
            valores[i] = rand.nextInt(100);
            System.out.println(valores[i]);
        }
        for(int i=0;i<20;i++) {
            if (valores[i] < min)
                min = valores[i];
            if (valores[i] > max)
                max = valores[i];
        }
        System.out.println("O valor máximo é :"+max+" e o valor mínimo é: "+min);
    }
}