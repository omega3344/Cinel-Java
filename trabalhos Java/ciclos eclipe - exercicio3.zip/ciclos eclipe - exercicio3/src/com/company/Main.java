package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("introduza um número: ");

        int num = scan.nextInt();

        int i;

        for (i=1;i<num;i++){
            if(num%i==0)
                System.out.println(num + " é divisivel por "+i);
        }
    }
}