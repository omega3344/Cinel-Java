package simulador;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("Indique a altura em cms: ");
        double alt = scan.nextDouble();
        System.out.println("Indique o sexo (1-M ou 2-F): ");
        double s = scan.nextDouble();

        System.out.println("O seu peso ideal é: "+calcular(s, alt));
    }

    public static double calcular (double s, double alt){

        return (s==1) ? (alt * 0.727 - 58) : (alt * 0.621 - 44.7);
    }
}
