package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        int num;

        do {
            System.out.println("Introduza um número entre 100 e 1000:");
            num = scan.nextInt();
        }while (num<100 || num>1000);

        int soma = 0;

        while (num>0){
            soma+= num%10;
            num=num/10;
        }

        System.out.println("A soma é: "+soma);
    }
}