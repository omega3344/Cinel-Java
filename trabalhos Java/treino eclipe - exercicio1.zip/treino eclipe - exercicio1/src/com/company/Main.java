package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Introduza dois números: ");
        int a = scanner.nextInt();
        int b = scanner.nextInt();

        int soma = a+b;
        double media = ((a+b)/2);
        int maior,menor;

        if(a>b){
            maior = a;
            menor = b;}
        else{
            maior = b;
            menor = a;}

        System.out.println("A soma de "+a+" e "+b+" é: "+soma);
        System.out.println("A média é: "+media);
        System.out.println("O número maior é: "+maior+" e o número menor é: "+menor);

    }
}
