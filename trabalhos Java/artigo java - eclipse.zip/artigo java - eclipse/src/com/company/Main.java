package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Introduza o preço do artigo :");

        double artigo = scanner.nextDouble();
        double desconto = 0;

        if(artigo<=2500)
            desconto = (artigo*.05);
        if((artigo>2500) && (artigo<=5000))
            desconto = (artigo*.10);
        if((artigo>5000) && (artigo<=10000))
            desconto = (artigo*.20);
        if(artigo>10000)
            desconto = (artigo*.40);

        System.out.println("O valor do desconto é: "+desconto);

    }
}
