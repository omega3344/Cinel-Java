package com.company;

import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        Random rand = new Random();

        int[] vendas = new int[100];
        int menu;
        double[] resultados = new double[4];

        System.out.println("Vendas efetuadas: ");
        for (int i = 0; i < 100; i++) {
            vendas[i] = rand.nextInt(90) + 10;
            System.out.println(vendas[i]);
        }

        do {
            System.out.println("1 - Média das vendas");
            System.out.println("2 - Venda mais alta");
            System.out.println("3 - Venda mínima");
            System.out.println("4 - A Moda das vendas");
            System.out.println("5 - Ver resultados");
            System.out.println("Escolha uma opção ou 0 para sair");

            menu = scan.nextInt();

            switch (menu) {
                case 0:
                    break;
                case 1:
                    resultados[0] = media(vendas);
                    break;
                case 2:
                    resultados[1] = maisAlta(vendas);
                    break;
                case 3:
                    resultados[2] = minima(vendas);
                    break;
                case 4:
                    resultados[3] = moda(vendas);
                    break;
                case 5:
                    System.out.println("\n Média: " + resultados[0] + "\n Venda mais alta: " + resultados[1] + "\n Venda mínima: " + resultados[2] + "\n Moda das vendas: " + resultados[3]);
                    break;
                default:
                    System.out.println("A opção não é válida");
                    break;
            }
        } while (menu != 0);
    }

    private static double media(int[] vendas) {

        double media = 0;
        for (int i = 0; i < 100; i++) {
            media += vendas[i];
        }
        return media / 100;
    }

    private static int maisAlta(int[] vendas) {

        int maisAlta = 0;
        for (int i = 0; i < 100; i++) {
            if (vendas[i] > maisAlta)
                maisAlta = vendas[i];
        }
        return maisAlta;
    }

    private static int minima(int[] vendas) {

        int minima = 100;
        for (int i = 0; i < 100; i++) {
            if (vendas[i] < minima)
                minima = vendas[i];
        }
        return minima;

    }

    private static int moda(int[] vendas) {

        int l = 0;
        int k = 0;
        int moda = 0;

        for (int i = 0; i < 100; i++) {
            for (int j = 0; j < 100; j++) {
                if (vendas[i] == vendas[j])
                    k++;
            }
            if (k > l) {
                moda = vendas[i];
                l = k;
            }
        }
        return moda;
    }
}

