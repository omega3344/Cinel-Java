package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        int[][] mat = new int[5][5];
        lerMatriz(mat);
        encontrar(mat);
    }

    private static void lerMatriz(int[][] mat) {

        Scanner scan = new Scanner(System.in);
        System.out.println("\nDigite números inteiros: ");
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                System.out.println((i + 1) + "," + (j + 1) + ":");
                mat[i][j] = scan.nextInt();
            }
        }
    }

    private static void encontrar(int[][] mat) {

        Scanner scan = new Scanner(System.in);
        System.out.println("Indique o número a encontrar: ");
        int n = scan.nextInt();
        int k=0;
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                if (mat[i][j] == n) {
                    System.out.println("encontrado na posição " + i + "," + j);
                    k++;
                }
            }
        }
        if(k==0)
            System.out.println("Não existe nenhum "+n+" na matriz!");
    }

}