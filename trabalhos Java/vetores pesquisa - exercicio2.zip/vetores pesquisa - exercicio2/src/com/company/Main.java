package com.company;

import java.util.Random;

public class Main {

    public static void main(String[] args) {

        Random rand = new Random();

        int[] valores = new int[20];
        int count;

        for(int i=0;i<20;i++){
            valores[i] = rand.nextInt(100);
            System.out.println(valores[i]);
        }
        for(int i=0;i<20;i++) {
            count = 0;
            for(int j=0;j<20;j++){
                if (valores[i]==valores[j])
                    count++;
            }
            if(count>1)
                System.out.println("O valor "+valores[i]+" está duplicado");
        }
    }
}