package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        int i;

        System.out.println("Números ímpares entre 100 e 200:");

        for (i=100;i<201;i++) {
            if(i%2!=0)
                System.out.println(i);
        }
    }
}