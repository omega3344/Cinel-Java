package com.company;

public class Main {

    public static void main(String[] args) {

        double[] valores = {6,6,18,12,14,15,4,16,9,11};
        double soma = 0;

        for(int i=0;i<10;i++){
            soma+=valores[i];
        }
        double media = soma/10;

        System.out.println("A média dos 10 valores é: "+media);
    }
}
