package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("Introduza o número inicial: ");
        int num = scan.nextInt();
        System.out.println("Introduza o número de repetições: ");
        int rep = scan.nextInt();

        for(int i=1;i<=rep;i++) {
            int alg=num;
            for (int j = 0; j < i; j++) {
                System.out.print(alg);
                alg++;
            }
            System.out.println();
        }
    }
}
