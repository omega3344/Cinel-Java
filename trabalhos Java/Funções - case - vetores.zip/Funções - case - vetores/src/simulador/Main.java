package simulador;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        int[] vetor1 = new int[5];
        int[] vetor2 = new int[5];
        int op;

        do {
            System.out.println("1 - Preencher");
            System.out.println("2 - Listar");
            System.out.println("3 - Trocar conteúdos");
            System.out.println("4 - Alterar um valor");
            System.out.println("5 - Alterar para dobro");
            System.out.println("6 - Apagar um valor");
            System.out.println("Escolha uma opção ou 0 para sair");

            op = scan.nextInt();

            switch (op) {
                case 0:
                    break;
                case 1:
                    preencher(vetor1, vetor2);
                    break;
                case 2:
                    listar(vetor1, vetor2);
                    break;
                case 3:
                    trocar(vetor1, vetor2);
                    break;
                case 4:
                    System.out.println("Qual o vetor que quer alterar? ");
                    int v1 = scan.nextInt();
                    System.out.println("Qual a posição que quer alterar? ");
                    int p = scan.nextInt();
                    System.out.println("Qual o novo valor a introduzir? ");
                    int val = scan.nextInt();
                    alterarvalor(vetor1,vetor2,v1,p, val);
                    break;
                case 5:
                    System.out.println("Qual o número que quer dobrar? ");
                    int num = scan.nextInt();
                    dobro(vetor1,vetor2,num);
                    break;
                case 6:
                    System.out.println("Qual o vetor que quer alterar? ");
                    int v3 = scan.nextInt();
                    System.out.println("Qual a posição que quer apagar? ");
                    int p3 = scan.nextInt();
                    apagar(vetor1,vetor2,v3,p3);
                    break;
                default:
                    System.out.println("A opção não é válida");
                    break;
            }
        } while (op != 0);
    }

    private static void preencher(int[] vetor1, int[] vetor2) {

        Random rand = new Random();
        for(int i=0;i<5;i++){
            vetor1[i] = rand.nextInt(99);
            vetor2[i] = rand.nextInt(99);
        }
        System.out.println("Vetores preenchidos");
    }

    private static void listar(int[] vetor1, int[] vetor2) {

        System.out.println("Vetor1: "+ Arrays.toString(vetor1));
        System.out.println("Vetor2: "+ Arrays.toString(vetor2));
    }
    private static void trocar(int[] vetor1, int[] vetor2) {

        int a;
        for(int i=0;i<5;i++){
            a = vetor1[i];
            vetor1[i] = vetor2[i];
            vetor2[i] = a;
        }
        System.out.println("Vetores trocados");
    }
    private static int[] alterarvalor(int[] vetor1, int[] vetor2, int v1, int p, int val) {

        System.out.println("Valor trocado");
        if(v1==1) {
            vetor1[p] = val;
            return vetor1;
        }
        if(v1==2) {
            vetor2[p] = val;
            return vetor2;
        }
        return vetor2;
    }
    private static int[] dobro(int[] vetor1, int[] vetor2, int num) {

        System.out.println("Valor trocado");
        for(int i=0;i<5;i++) {
            if (vetor1[i] == num){
                vetor1[i] = 2 * num;
                return vetor1;}
            if (vetor2[i]==num){
                vetor2[i] = 2 * num;
                return vetor2;}
        }
        return vetor2;
    }
    private static int[] apagar(int[] vetor1, int[] vetor2, int v3, int p3) {

        System.out.println("Valor apagado");
        if (v3 == 1) {
            vetor1[p3] = 0;
            return vetor1;
        }
        if (v3 == 2) {
            vetor2[p3] = 0;
            return vetor2;
        }
        return vetor2;
    }
}
