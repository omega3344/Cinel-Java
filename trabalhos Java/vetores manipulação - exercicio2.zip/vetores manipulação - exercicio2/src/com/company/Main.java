package com.company;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        Random rand = new Random();
        ArrayList<Integer> valores = new ArrayList();

        for(int i=0;i<20;i++){
            valores.add(rand.nextInt(100));
            System.out.print(valores.get(i)+"  ");
        }
        System.out.println();
        System.out.println("Indique qual o novo valor a inserir: ");
        int c = scan.nextInt();
        System.out.println("Indique onde quer inserir um novo valor (1-início 2-fim 3-outra posição): ");

        switch (scan.nextInt()) {
            case 1:
                valores.add(0, c);
                break;
            case 2:
                valores.add((valores.size()), c);
                break;
            case 3:
                System.out.println("Qual a posição: ");
                int p = scan.nextInt();
                valores.add(p-1, c);
                break;
        }
        for(int j=0;j<valores.size();j++) {
            System.out.print(valores.get(j)+"  ");
        }
    }
}