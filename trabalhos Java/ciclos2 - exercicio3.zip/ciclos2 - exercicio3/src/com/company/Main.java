package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("Introduza o nÃºmero de repetiÃ§Ãµes: ");
        int rep = scan.nextInt();

        for(int i=1;i<=rep;i++) {
            System.out.format("%"+(10-i)+"s", "");
            for (int j = 1; j < i+1; j++) {
                System.out.print(i+" ");
            }
            System.out.println();
        }
    }
}