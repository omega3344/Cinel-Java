package simulador;

import java.util.Arrays;

public class Main {

    public static void main(String[] args) {

        int[] a = {12,1,41};

        System.out.println("Vetor ordenado: "+ Arrays.toString(ordenar(a)));
    }
    public static int[] ordenar(int[]a){

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (a[i] < a[j]) {
                    int temp = a[i];
                    a[i] = a[j];
                    a[j] = temp;
                }
            }
        }
        return (a);
    }
}



