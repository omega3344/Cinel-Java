package com.company;

public class Main {

    public static void main(String[] args) {

        int i;

        for (i=1;i<100;i++){
            if((i%7==0)&&(i%2!=0))
                System.out.println(i + " é múltiplo de 7 e não é múltiplo de 2:");
        }
    }
}
