package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        int num,i;
        int soma = 0;

        for (i=0;i<10;i++) {
            do {
                System.out.println("Introduza o "+(i+1)+"º número par:");
                num = scan.nextInt();
            } while (num % 2 != 0);
            soma += num;
        }
        System.out.println("A soma dos 10 números pares é: "+soma);
    }
}