package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        int a,i,p;

        Scanner scanner = new Scanner(System.in);

        System.out.println("Introduza um número: ");
        a = scanner.nextInt();

        p = 0;
        for (i = 1; i <= a; i++) {
            if (a % i == 0) {
                p++;
            }
        }
        if (p == 2)
            System.out.println("O número " + a + " é primo");
        else
            System.out.println("O número " + a + " não é primo");
    }
}
