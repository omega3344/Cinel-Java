package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        int a;

        Scanner scanner = new Scanner(System.in);

        System.out.println("Introduza um número: ");
        a = scanner.nextInt();

        System.out.println("O dobro de "+a+" é "+(a*2)+", a metade é "+(a*.5)+", o antecessor é "+(a-1)+" e o sucessor é "+(a+1));
    }
}