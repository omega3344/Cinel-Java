package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        int notas[] = new int[3];

        System.out.println("Introduza o nome do aluno: ");
        String nome = scan.nextLine();

        for (int i = 0; i < 3; i++) {
            System.out.println("Introduza o valor da nota " + (i + 1));
            notas[i] = scan.nextInt();
            if(notas[i]<0||notas[i]>20){
                System.out.println("Nota inválida! - introduza novamente");
                notas[i] = scan.nextInt();
            }
        }
        double media = notas[0] * 0.3 + notas[1] * 0.5 + notas[2] * 0.2;
        if (media < 8)
            System.out.printf("Aluno: %s Nota: %.2f  Situação: REPROVADO \n", nome,media);
        if (media >= 8 && media < 10)
            System.out.printf("Aluno: %s Nota: %.2f  Situação: ORAL \n", nome,media);
        if (media >= 10)
            System.out.printf("Aluno: %s Nota: %.2f  Situação: APROVADO \n", nome,media);
    }
}
