package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int x;
        do {
            System.out.println("Introduza o 1º número a calcular: ");
            int a = scan.nextInt();
            System.out.println("Introduza o 2º número a calcular: ");
            int b = scan.nextInt();

            System.out.println("Indique qual a operação a realizar:");
            System.out.println("1 - Soma");
            System.out.println("2 - Multiplicação");
            System.out.println("3 - Divisão");
            System.out.println("4 - Subtração");

            switch (scan.nextInt()) {
                case 1:
                    System.out.printf("O número " + a + " somado com " + b + " é igual a %d%n", a + b);
                    break;
                case 2:
                    System.out.printf("O número " + a + " multiplicado por " + b + " é igual a %d%n", a * b);
                    break;
                case 3:
                    System.out.printf("O número " + a + " dividido por " + b + " é igual a %d.3%n", a / b);
                    break;
                case 4:
                    System.out.printf("O número " + a + " subtraído de " + b + " é igual a %d%n", a - b);
                    break;
            }
            System.out.println("Introduza 0 para nova operação ou outra tecla para sair");
            x = scan.nextInt();
        }while (x==0);
    }
}
