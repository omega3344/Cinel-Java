package simulador;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("Introduza um número inteiro: ");
        int num = scan.nextInt();

        if(verificar(num)==true){
            System.out.println("O número é positivo");
        }else
            System.out.println("O número é negativo");
    }

    public static boolean verificar (int num){

        return (num>=0) ? true : false;
    }
}

