package simulador;

import java.util.Scanner;
import java.util.Random;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        Random rand = new Random();

        int[] a = new int[5];
        int[] b = new int[5];

        for(int i=0;i<5;i++) {
            a[i] = rand.nextInt(100);
            b[i] = rand.nextInt(100);
        }

        System.out.println("O resultado da sua opção de cálculo é: "+opcoes(a,b));
    }

    public static double opcoes (int[] a, int[] b){

        Scanner scan = new Scanner(System.in);

        System.out.println("Introduza a opção de cálculo:");
        System.out.println("1- Somatório do vetor A");
        System.out.println("2- Média dos vetores A e B");
        System.out.println("3- Máximo dos vetores A e B");
        int o = scan.nextInt();


        switch (o){
            case 1:
                double sum = 0;
                for(int i=0;i<5;i++)
                    sum+=a[i];
                return sum;
            case 2:
                double media = 0;
                for(int i=0;i<5;i++)
                    media+=a[i]+b[i];
                return (media/10);
            case 3:
                double max = Double.MIN_VALUE;
                for(int i=0;i<5;i++) {
                    if (a[i] > max)
                        max = a[i];
                    if (b[i] > max)
                        max = b[i];
                }
                return max;
        }
        return 0;
    }
}

