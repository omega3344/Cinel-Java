package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        int num;

        do {
            System.out.println("Introduza um número entre 100 e 1000:");
            num = scan.nextInt();
        }while (num<100 || num>1000);

        String string = Integer.toString(num);
        int n = string.length();
        int soma = 0;
        int i;

        for(i=0;i<n;i++){
            char c=Integer.toString(num).charAt(i);
            soma = soma + Integer.parseInt(String.valueOf(c));
        }

        System.out.println("A soma é: "+soma);

    }
}