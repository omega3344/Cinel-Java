package simulador;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        int n1,n2,num;

        System.out.println("Indique o limite inferior: ");
        n1 = scan.nextInt();
        System.out.println("Indique o limite superior: ");
        n2 = scan.nextInt();

        do {
            System.out.println("Introduza um número dentro do intervalo: ");
            num = scan.nextInt();

        }while (verificar(n1,n2,num)==false);


    }
    public static boolean verificar(int n1,int n2,int num){

        if(num<n1 || num>n2){
            System.out.println("Número inválido. Digite novamente!");
            return false;
        }else{
            return true;
        }
    }

}
