package cartao;

public class cartao {

    int nif;
    String nome;
    double saldo;
    double totalAc;

    void movimento (double valor){

        this.saldo = this.saldo - valor;
    }

    boolean retirar (double valor) {

        if (this.saldo < valor) {
            return false;
        } else {
            return true;
        }
    }
}
