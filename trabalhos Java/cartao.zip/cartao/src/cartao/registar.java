package cartao;

import java.util.Scanner;

public class registar {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        int menu, compra;
        double valor;
        cartao meuCartao = new cartao();

        meuCartao.nome = "JOÃO ALVES";
        meuCartao.saldo = 100;
        meuCartao.totalAc = 2000;

        do {
            System.out.println("Indique a operação a efetuar:");
            System.out.println("1 - Registar compras");
            System.out.println("2 - Utilizar saldo");
            System.out.println("3 - Ver informação do cartão");
            System.out.println("Escolha uma opção ou 0 para sair");

            menu = scan.nextInt();

            switch (menu) {
                case 0:
                    break;
                case 1:
                    System.out.print("Insira o valor da compra a acumular: ");
                    compra = scan.nextInt();
                    meuCartao.saldo += compra*20;
                    meuCartao.totalAc += compra;
                    break;
                case 2:
                    System.out.print("Insira o valor da compra a efetuar: ");
                    valor = scan.nextInt()*20;
                    if(meuCartao.retirar(valor)==true) {
                        meuCartao.movimento(valor);
                    }else{
                        System.out.println("Saldo insuficiente!");
                    }
                    break;
                case 3:
                    System.out.println("O nome do cartão é: "+ meuCartao.nome);
                    System.out.println("Os pontos no cartao: "+ meuCartao.saldo);
                    break;
                default:
                    System.out.println("A opção não é válida");
                    break;
            }
        } while (menu != 0);
    }
}
