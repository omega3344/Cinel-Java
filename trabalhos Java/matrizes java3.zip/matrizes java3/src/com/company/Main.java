package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        int[][] mat1 = new int[3][3];
        int[][] mat2 = new int[3][3];
        lerMatriz(mat1);
        lerMatriz(mat2);
        int[][]mat3 = difer(mat1, mat2);
        mostrarResultado(mat3);
    }

    private static void lerMatriz(int[][] mat) {

        Scanner scan = new Scanner(System.in);
        System.out.println("\nDigite números inteiros: ");
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                System.out.println((i + 1) + "," + (j + 1) + ":");
                mat[i][j] = scan.nextInt();
            }
        }
    }

    private static int[] encontrarPares(int[][] mat, int[] pares) {

        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                if (mat[i][j] % 2 == 0)
                    pares[i + j] = mat[i][j];
            }
        }
        return pares;
    }

    private static void mostrarResultado(int[][] mat) {

        System.out.println("Diferença entre matrizes:");
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                System.out.print(mat[i][j] + " ");
            }
            System.out.println();
        }
    }

    private static int[][] difer(int[][] mat1, int[][] mat2) {

        int[][] mat3 = new int[mat1.length][mat1[0].length];
        for (int i = 0; i < mat1.length; i++) {
            for (int j = 0; j < mat1[i].length; j++) {
                mat3[i][j] = mat2[i][j] - mat1[i][j];
            }
        }
        return mat3;
    }
}