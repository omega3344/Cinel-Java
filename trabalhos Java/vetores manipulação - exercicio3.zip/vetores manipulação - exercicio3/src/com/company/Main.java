package com.company;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        Random rand = new Random();
        ArrayList<Integer> pares = new ArrayList();
        ArrayList<Integer> impares = new ArrayList();

        for(int i=0;i<20;i++) {
            int valor = rand.nextInt(100);
            if (valor % 2 == 0) {
                pares.add(valor);
            } else {
                impares.add(valor);
            }
        }

        System.out.println("Vetor de números pares: ");
        for(int j=0;j<pares.size();j++) {
            System.out.print(pares.get(j) + "  ");
        }
        System.out.println();
        System.out.println("Vetor de números impares: ");
        for(int k=0;k<impares.size();k++) {
            System.out.print(impares.get(k)+"  ");
        }
    }
}