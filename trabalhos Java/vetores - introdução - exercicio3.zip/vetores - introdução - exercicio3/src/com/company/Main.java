package com.company;

import java.util.Random;

public class Main {

    public static void main(String[] args) {

        Random rand = new Random();
        double[] valores = new double[10];
        double soma = 0;

        for(int i=0;i<10;i++){
            valores[i] = rand.nextDouble(20)+1;
            soma+=valores[i];
        }
        double media = soma/10;

        System.out.printf("A média dos 10 valores é: %.2f %n",media);
    }
}