package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        int dig = 0;
        int num;
        do{
        System.out.println("Introduza um valor entre 1 e 10000: ");
        num = scan.nextInt();
        }while (num<1||num>10000);
        while (num>0) {
            dig++;
            num = num / 10;
        }
        System.out.println("O número "+num+" tem "+dig+" dígitos");
    }
}
