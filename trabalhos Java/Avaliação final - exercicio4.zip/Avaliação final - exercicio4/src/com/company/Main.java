package com.company;

import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        int[] vetor1 = new int[5];
        int[] vetor2 = new int[5];
        int[] vetor3 = new int[10];
        int[] repetidos = new int[10];
        int menu;

        do {
            System.out.println("1 - Preencher vetores automáticamente");
            System.out.println("2 - Juntar os dois vetores");
            System.out.println("3 - Procurar numeros repetidos");
            System.out.println("4 - Listar vetor à escolha");
            System.out.println("Escolha uma opção ou 0 para sair");

            menu = scan.nextInt();

            switch (menu) {
                case 0:
                    break;
                case 1:
                    preencher(vetor1, vetor2);
                    break;
                case 2:
                    juntar(vetor1, vetor2,vetor3);
                    break;
                case 3:
                    procurar(vetor3);
                    break;
                case 4:
                    int lista;
                    do {
                        System.out.println("\nQual o vetor que quer listar: ");
                        System.out.println("1 - Vetor 1");
                        System.out.println("2 - Vetor 2");
                        System.out.println("3 - Vetor 3");
                        System.out.println("4 - Vetor Repetidos");
                        System.out.println("0 - Para terminar");
                        lista = scan.nextInt();
                        switch (lista) {
                            case 1:
                                for (int i = 0; i < 5; i++)
                                    System.out.print(vetor1[i] + " ");
                                break;
                            case 2:
                                for (int i = 0; i < 5; i++)
                                    System.out.print(vetor2[i] + " ");
                                break;
                            case 3:
                                for (int i = 0; i < 10; i++)
                                    System.out.printf(vetor3[i] + " ");
                                break;
                            case 4:
                                for (int i = 0; i < 10; i++)
                                    if (repetidos[i] != 0)
                                        System.out.print(vetor3[i] + " ");
                                break;
                            default:
                                System.out.println("A opção não é válida");
                                break;
                        }
                    } while (lista != 0);
                default:
                    System.out.println("A opção não é válida");
                    break;
            }
        } while (menu != 0);
    }

    private static void preencher(int[] vetor1, int[] vetor2) {

        Random rand = new Random();
        for (int i = 0; i < 5; i++) {
            vetor1[i] = rand.nextInt(99) + 1;
            vetor2[i] = rand.nextInt(99) + 1;
        }
    }

    private static void juntar(int[] vetor1, int[] vetor2, int[] vetor3) {

        for (int i = 0; i < 5; i++) {
            vetor3[i] = vetor1[i];
            vetor3[i + 5] = vetor2[i];
        }
    }

    private static int[] procurar(int[] vetor3) {

        int[] repetidos = new int[10];
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                if ((vetor3[i] == vetor3[j]) && (i != j)) ;
                repetidos[i] = vetor3[i];
            }
        }
        return repetidos;
    }
}
