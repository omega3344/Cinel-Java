package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        int i;
        int idade = 0;
        int contador = 0;

        for (i = 1; i < 6; i++) {
            do {
                System.out.println("Introduza a " + i + "ª idade:");
                idade = scan.nextInt();
            } while ((idade < 7) || (idade > 77));
            if (idade >= 18)
                contador++;
        }
        System.out.println("O número de idades de adultos introduzidas foi: "+contador);
    }
}

