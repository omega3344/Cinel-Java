package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);
        int num;

        do {
            System.out.println("Introduza um número inteiro positivo:");
            num = scan.nextInt();
        }while (num<0);

        int i = 0;

        while (num > 0) {
            i = i*10;
            i += (num % 10);
            num = num/10;
        }
        System.out.println("O número invertido é: "+i);
    }
}