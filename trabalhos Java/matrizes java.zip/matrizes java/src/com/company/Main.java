package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        int numLin = lerNumero("linhas");
        int numCol = lerNumero("colunas");
        int[][] m1 = new int[numLin][numCol];
        lerMatriz(m1);
        int[][] m2 = clonar(m1);
        int[][] m3 = somar(m1, m2);
        mostrarMatriz(m1);
        mostrarMatriz(m2);
        mostrarMatriz(m3);
    }

    private static int lerNumero(String s) {

        Scanner scan = new Scanner(System.in);
        System.out.println("\nInsira o número de " + s + ":");
        int n = scan.nextInt();
        while (n <= 0) {
            System.out.println("Valor inválido!!" + "Introduza novo valor de " + s + ":");
            n = scan.nextInt();
        }
        return n;
    }

    private static void lerMatriz(int[][] mat) {

        Scanner scan = new Scanner(System.in);
        System.out.println("\nDigite números inteiros: ");
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                System.out.println((i + 1) + "," + (j + 1) + ":");
                mat[i][j] = scan.nextInt();
            }
        }
    }

    private static int[][] clonar(int[][] mat1) {

        int[][] mat2 = new int[mat1.length][mat1[0].length];
        for (int i = 0; i < mat1.length; i++) {
            for (int j = 0; j < mat1[i].length; j++) {
                mat2[i][j] = mat1[i][j];
            }
        }
        return mat2;
    }

    private static int[][] somar(int[][] mat1, int[][] mat2) {

        int[][] mat3 = new int[mat1.length][mat1[0].length];
        for (int i = 0; i < mat1.length; i++) {
            for (int j = 0; j < mat1[i].length; j++) {
                mat3[i][j] = mat2[i][j] + mat1[i][j];
            }
        }
        return mat3;
    }

    private static void mostrarMatriz(int[][] mat) {

        System.out.println("\nMatriz: ");
        for (int i = 0; i < mat.length; i++) {
            for (int j = 0; j < mat[i].length; j++) {
                System.out.printf("%6d", mat[i][j]);
            }
            System.out.println();
        }
    }
}